document.addEventListener('DOMContentLoaded', function(){
    new Runner('.interstitial-wrapper');
});